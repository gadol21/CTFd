"""Examples of various :func:`.orm.relationship` configurations,
which make use of the ``primaryjoin`` argument to compose special types
of join conditions.

.. autosource::

"""