from datafreeze.app import freeze

__all__ = [freeze]
