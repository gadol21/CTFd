SQLAlchemy-Utils
================

|Build Status| |Version Status| |Downloads|


Various utility functions, new data types and helpers for SQLAlchemy.


Resources
---------

- `Documentation <https://sqlalchemy-utils.readthedocs.io/>`_
- `Issue Tracker <http://github.com/kvesteri/sqlalchemy-utils/issues>`_
- `Code <http://github.com/kvesteri/sqlalchemy-utils/>`_

.. |Build Status| image:: https://travis-ci.org/kvesteri/sqlalchemy-utils.svg?branch=master
   :target: https://travis-ci.org/kvesteri/sqlalchemy-utils
.. |Version Status| image:: https://img.shields.io/pypi/v/SQLAlchemy-Utils.svg
   :target: https://pypi.python.org/pypi/SQLAlchemy-Utils/
.. |Downloads| image:: https://img.shields.io/pypi/dm/SQLAlchemy-Utils.svg
   :target: https://pypi.python.org/pypi/SQLAlchemy-Utils/
