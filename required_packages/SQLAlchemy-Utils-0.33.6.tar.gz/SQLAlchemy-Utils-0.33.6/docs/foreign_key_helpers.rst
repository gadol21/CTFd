Foreign key helpers
===================

.. module:: sqlalchemy_utils.functions


dependent_objects
-----------------

.. autofunction:: dependent_objects


get_referencing_foreign_keys
----------------------------

.. autofunction:: get_referencing_foreign_keys


group_foreign_keys
------------------

.. autofunction:: group_foreign_keys


is_indexed_foreign_key
----------------------

.. autofunction:: is_indexed_foreign_key


merge_references
----------------

.. autofunction:: merge_references


non_indexed_foreign_keys
------------------------

.. autofunction:: non_indexed_foreign_keys
