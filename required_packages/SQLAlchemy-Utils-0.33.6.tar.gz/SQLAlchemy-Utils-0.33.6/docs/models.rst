Model mixins
============


Timestamp
---------

.. module:: sqlalchemy_utils.models

.. autoclass:: Timestamp


generic_repr
------------

.. module:: sqlalchemy_utils.models

.. autofunction:: generic_repr
