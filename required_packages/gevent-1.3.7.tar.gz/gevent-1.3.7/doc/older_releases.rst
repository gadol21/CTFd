==================================
 Information About Older Releases
==================================

.. toctree::


   whatsnew_1_2
   whatsnew_1_1
   whatsnew_1_0
   changelog_pre
