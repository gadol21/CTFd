=============================
Example unixsocket_client.py
=============================
.. literalinclude:: ../../examples/unixsocket_client.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/unixsocket_client.py>`_

