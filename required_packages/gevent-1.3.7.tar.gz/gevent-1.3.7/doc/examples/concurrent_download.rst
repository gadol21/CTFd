================================
 Example concurrent_download.py
================================
.. literalinclude:: ../../examples/concurrent_download.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/concurrent_download.py>`_
