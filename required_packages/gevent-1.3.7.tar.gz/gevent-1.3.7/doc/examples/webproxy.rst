=============================
Example webproxy.py
=============================
.. literalinclude:: ../../examples/webproxy.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/webproxy.py>`_

