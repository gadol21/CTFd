=============================
Example geventsendfile.py
=============================
.. literalinclude:: ../../examples/geventsendfile.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/geventsendfile.py>`_

