=============================================================
 :mod:`gevent.resolver.blocking` -- Non-cooperative resolver
=============================================================

.. automodule:: gevent.resolver.blocking
    :members:
