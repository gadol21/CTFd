:mod:`gevent.time` -- Makes *sleep* gevent aware
================================================

This module has all the members of :mod:`time`, but the *sleep*
function is :func:`gevent.sleep`.

.. automodule:: gevent.time
    :members:
