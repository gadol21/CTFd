==============================================================================================
 :mod:`gevent.signal` -- Cooperative implementation of special cases of :func:`signal.signal`
==============================================================================================

.. automodule:: gevent.signal
    :members:
