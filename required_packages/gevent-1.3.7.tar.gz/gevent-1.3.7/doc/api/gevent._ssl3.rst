===================================================================
 :mod:`gevent._ssl3` -- SSL wrapper for socket objects on Python 3
===================================================================

.. automodule:: gevent._ssl3
    :members:
