====================================================
 :mod:`gevent.select` -- Waiting for I/O completion
====================================================

.. automodule:: gevent.select
    :members:
