======================================================================================
 :mod:`gevent.ares` -- Backwards compatibility alias for :mod:`gevent.resolver.cares`
======================================================================================

.. automodule:: gevent.ares
    :members:
