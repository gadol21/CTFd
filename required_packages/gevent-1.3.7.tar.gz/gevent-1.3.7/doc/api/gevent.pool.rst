:mod:`gevent.pool` -- Managing greenlets in a group
===================================================

.. module:: gevent.pool

.. autoclass:: gevent.pool.Group
   :members:
   :inherited-members:

   .. automethod:: __len__
   .. automethod:: __contains__

.. autoclass:: gevent.pool.PoolFull
   :members:

.. autoclass:: gevent.pool.Pool
   :members:
