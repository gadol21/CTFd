============================================================================
 :mod:`gevent.fileobject` -- Wrappers to make file-like objects cooperative
============================================================================

.. automodule:: gevent.fileobject
    :members:
