======================================================================================
 :mod:`gevent._sslgte279` -- SSL wrapper for socket objects on Python 2.7.9 and above
======================================================================================

.. automodule:: gevent._sslgte279
    :members:
